/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.exemplo;

/**
 *
 * @author Viotti
 */
public class MA4_2708_Encapsulamento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // criar as variaveis para conversão
        int inteira = 345;
        float decimalPeq = 1234.8765f;
        double decimalGrande = 1234.7654;
        String numeros; //tipo de dados NÃO PRIMITIVO
        
        //conversão implicita
        decimalPeq = inteira;
        
        //conversão explicita (casting)
        inteira = (int)decimalPeq;
        
        numeros = "1234";
        //converter de String para int (wrapper)
        inteira = Integer.parseInt(numeros);
        
        //converter de int para String (wrapper)
        numeros = Integer.toString(inteira);
        
        //********************************************************************
        //criar uma variavel para Matematica
        Matematica mat;
        //criar um objeto e fazer com que mat se referencie a este objeto
        mat = new Matematica();
        
        //ou criar a variavel e o objeto ao mesmo tempo
        Matematica mat2 = new Matematica();
        
        //atribuir dados para nossos atributos do objeto
        //deve-se utilizar o método SETTER
        mat.setNumero1(-123);
        mat.setNumero2(765);
        
        //atribuir dados para outro objeto da mesma classe Matematica
        mat2.setNumero1(888);
        mat2.setNumero2(999);
        
        System.out.println("A soma dos numeros é: " + mat.soma());
        System.out.println("os numeros somados foram: " + mat.getNumero1() + 
                " e " + mat.getNumero2());
        
    }
    
}

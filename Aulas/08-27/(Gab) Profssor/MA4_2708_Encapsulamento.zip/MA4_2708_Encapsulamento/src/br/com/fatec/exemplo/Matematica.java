/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.exemplo;

/**
 * Esta classe permite o uso de operações matemáticas 
 * @author Viotti
 */
public class Matematica {
    //atributos
    private int numero1, numero2;
    
    //getters e setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        if(numero1 < 0) {
            //isso não é uma boa pratica de programação
            //é preciso utilizar o try..catch
            System.out.println("Erro!, número negativo");
        } else {
            this.numero1 = numero1;
        }
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {    
        this.numero2 = numero2;
    }

    //metodos
    /**
     * Possibilita a soma dos numeros da classe
     * @return A soma dos numeros
     */
    public int soma() {
        int resultado;
        resultado = numero1 + numero2;
        
        return resultado;
    }
    
    /**
     * Possibilita a multiplicação dos numeros da classe
     * @return A multiplicação dos numeros
     */
    public int multiplicacao() {
        return numero1 * numero2;
    }
}
